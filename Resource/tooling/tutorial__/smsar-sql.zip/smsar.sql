-- phpMyAdmin SQL Dump
-- version 2.7.0-pl1
-- http://www.phpmyadmin.net
-- 
-- Host: localhost
-- Generation Time: Apr 24, 2006 at 04:06 AM
-- Server version: 5.0.18
-- PHP Version: 5.1.1
-- 
-- Database: `smsar`
-- 

-- --------------------------------------------------------

-- 
-- Table structure for table `inbox`
-- 

CREATE TABLE `inbox` (
  `ID` int(10) unsigned NOT NULL auto_increment,
  `Pengirim` varchar(20) collate latin1_general_ci default NULL,
  `Waktu` datetime default NULL,
  `Teks` varchar(160) collate latin1_general_ci default NULL,
  PRIMARY KEY  (`ID`),
  UNIQUE KEY `ID` (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `inbox`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `kategori`
-- 

CREATE TABLE `kategori` (
  `ID` int(10) unsigned NOT NULL auto_increment,
  `Teks` varchar(20) collate latin1_general_ci default NULL,
  `Respond` varchar(160) collate latin1_general_ci default NULL,
  `Aktif` tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (`ID`),
  UNIQUE KEY `ID` (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=3 ;

-- 
-- Dumping data for table `kategori`
-- 

INSERT INTO `kategori` (`ID`, `Teks`, `Respond`, `Aktif`) VALUES (1, 'Default', '', 1);

-- --------------------------------------------------------

-- 
-- Table structure for table `logtable`
-- 

CREATE TABLE `logtable` (
  `ID` int(10) unsigned NOT NULL auto_increment,
  `Waktu` datetime default NULL,
  `Writer` varchar(20) collate latin1_general_ci default NULL,
  `LogText` varchar(50) collate latin1_general_ci default NULL,
  PRIMARY KEY  (`ID`),
  UNIQUE KEY `ID` (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `logtable`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `outbox`
-- 

CREATE TABLE `outbox` (
  `ID` int(10) unsigned NOT NULL auto_increment,
  `Tujuan` varchar(20) collate latin1_general_ci default NULL,
  `Teks` varchar(160) collate latin1_general_ci default NULL,
  PRIMARY KEY  (`ID`),
  UNIQUE KEY `ID` (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `outbox`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `pengguna`
-- 

CREATE TABLE `pengguna` (
  `username` varchar(15) collate latin1_general_ci NOT NULL default '',
  `password` varchar(20) collate latin1_general_ci NOT NULL default '',
  `Nama` varchar(30) collate latin1_general_ci NOT NULL default '',
  `Aktif` tinyint(1) NOT NULL default '0',
  `Privilige` int(1) NOT NULL default '0',
  PRIMARY KEY  (`username`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

-- 
-- Dumping data for table `pengguna`
-- 

INSERT INTO `pengguna` (`username`, `password`, `Nama`, `Aktif`, `Privilige`) VALUES ('admin', '08d0766604979b40', 'Administrator', 1, 255);

-- --------------------------------------------------------

-- 
-- Table structure for table `pesan`
-- 

CREATE TABLE `pesan` (
  `ID` int(10) unsigned NOT NULL auto_increment,
  `Pengirim` varchar(20) collate latin1_general_ci default NULL,
  `Waktu` datetime default NULL,
  `Teks` varchar(160) collate latin1_general_ci default NULL,
  `Kategori` int(11) default NULL,
  `Flag` smallint(6) default NULL,
  PRIMARY KEY  (`ID`),
  UNIQUE KEY `ID` (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `pesan`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `phonebook`
-- 

CREATE TABLE `phonebook` (
  `ID` int(10) unsigned NOT NULL auto_increment,
  `Nomer` varchar(20) collate latin1_general_ci default NULL,
  `Nama` varchar(20) collate latin1_general_ci default NULL,
  PRIMARY KEY  (`ID`),
  UNIQUE KEY `ID` (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `phonebook`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `sent`
-- 

CREATE TABLE `sent` (
  `ID` int(10) unsigned NOT NULL auto_increment,
  `Tujuan` varchar(20) collate latin1_general_ci default NULL,
  `Waktu` datetime default NULL,
  `Teks` varchar(160) collate latin1_general_ci default NULL,
  PRIMARY KEY  (`ID`),
  UNIQUE KEY `ID` (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `sent`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `temppesan`
-- 

CREATE TABLE `temppesan` (
  `pengirim` varchar(20) collate latin1_general_ci NOT NULL,
  `teks` varchar(160) collate latin1_general_ci NOT NULL,
  `waktu` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

-- 
-- Dumping data for table `temppesan`
-- 

