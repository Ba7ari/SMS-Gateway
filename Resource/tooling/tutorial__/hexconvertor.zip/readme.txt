HexConvertor v1.0
=================

HexConvertor is a small utility to easily convert binary, octal, decimal and hexadecimal values to eachother.


This program needs the VB5 runtimes (you can download them at http://www.wimsprograms.com/vb5run/).


Enjoy !

The author,
Wim Heirman
http://www.wimsprograms.com/
wimh@dma.be
